# lab_4
commandes shell de base
